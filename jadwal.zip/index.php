<?php require_once('koneksi.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 7) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['username'])) {
  $loginUsername=$_POST['username'];
  $password=$_POST['password'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "home.php?page=beranda";
  $boss = "home.php?page=main";
  $MM_redirectLoginFailed = "index.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($db, $koneksi);
  
  $LoginRS__query=sprintf("SELECT nama, username, password, role, unit FROM tb_user WHERE username=%s AND password=%s ",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $koneksi) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	 
	   $panggil = mysql_fetch_assoc($LoginRS);
     $_SESSION['nama'] = $panggil['nama'];
     $_SESSION['role'] = $panggil['role'];
          $_SESSION['unit'] = $panggil['unit'];



    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }

  if($_SESSION['role']=="boss"){
    header("Location: " . $boss );
  }
}
?>
<!DOCTYPE html>
<html><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>APLIKASI SURAT</title>
<link href="./assets/bootstrap-3.3.7/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

<style>  

body
 {
     background-image: url(./assets/bgimage.jpg);
     background-repeat: no-repeat;
 }
.container {
	padding-top:150px;
}
.panel-default {
    opacity: .9;
    -webkit-box-shadow: 0px 7px 24px 1px rgba(0,0,0,0.45);
    -moz-box-shadow: 0px 7px 24px 1px rgba(0,0,0,0.45);
    box-shadow: 0px 7px 24px 1px rgba(0,0,0,0.45);    
}

  .ui-datepicker {
width: 7cm; 
}

</style>
</head>
<body>
<div class="container">
	<div class="row">
	<h1><center>Silahkan Login</center></h1>
		<div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
			<div class="panel panel-default">
				<div class="panel-body">
					<form method="post" class="form-signin" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>">

						<fieldset>
			
							<div class="row" style="margin-top:20px">

								<div class="col-sm-12 col-md-10  col-md-offset-1 ">
									<div class="form-group">
										<label>Username:</label>
										<div class="input-group"> <span class="input-group-addon"> <i class="glyphicon glyphicon-user"></i> </span>
											<input type="text" class="form-control" name="username" placeholder="Username" required="" autofocus="">
										</div>
									</div>
									<div class="form-group">
										<label>Password:</label>
										<div class="input-group"> <span class="input-group-addon"> <i class="glyphicon glyphicon-lock"></i> </span>
											<input type="password" class="form-control" name="password" placeholder="Password" required="">
										</div>
									</div>								   
									<div class="form-group">
									
										<input type="submit" class="btn btn-success pull-right" value="Log In">
									</div>               
								</div>
							</div>
						</fieldset>
					</form>  
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>