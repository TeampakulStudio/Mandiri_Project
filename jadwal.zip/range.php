<?php
// Range.php


if(isset($_POST["From"]))
{

	$result = '<table class="table table-bordered">
<tr>
<th width="75%">List To Do</th>
<th width="25%">Durasi</th>
</tr>';

	$query = "SELECT * FROM jadwal WHERE tanggal = '".$_POST["From"]."'";
	$sql = mysqli_query($conn, $query);
	$result .='
	';
	if(mysqli_num_rows($sql) > 0)
	{
		 $i=0;
		while($row = mysqli_fetch_array($sql))
		{
			$result .='
			

    <tr>
<td>'.$row["list_todo"].' </td>
<td>'.$row["durasi"].' Jam</td>
 </tr>';
		}
	}
	else
	{
		$result .='<tr>
    <td colspan="5">Tidak ada Schedule</td>
    </tr>
		';
	}
	$result .='';
	echo $result;
}

?>    