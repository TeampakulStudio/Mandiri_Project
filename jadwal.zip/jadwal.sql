-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 19, 2018 at 08:03 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jadwal`
--

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE IF NOT EXISTS `jadwal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `list_todo` varchar(111) NOT NULL,
  `durasi` varchar(100) NOT NULL,
  `tanggal` date NOT NULL,
  `user` varchar(111) NOT NULL,
  `unit` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `jadwal`
--

INSERT INTO `jadwal` (`id`, `list_todo`, `durasi`, `tanggal`, `user`, `unit`) VALUES
(37, 'Minum', '1', '2018-02-19', 'Aqli', ''),
(39, 'Makan', '1', '2018-02-19', 'Mentes', ''),
(40, 'Makan Sapi Goreng Di wadah kudamerta', '1', '2018-02-19', 'Aqli', ''),
(41, 'Mandi', '1', '2018-02-19', 'Aqli', ''),
(42, 'Mandi', '1', '2018-02-19', 'Aqli', ''),
(43, 'wkwkw', '1', '2018-02-19', 'rudini', ''),
(44, 'baranoi', '1', '2018-02-19', 'Aqli', 'CV');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE IF NOT EXISTS `tb_user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(40) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `unit` varchar(10) NOT NULL,
  `role` varchar(10) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id_user`, `nama`, `username`, `password`, `unit`, `role`) VALUES
(22, 'rudini', 'rudini', 'rudini', 'CCLA', 'user'),
(23, 'Aqli', 'admin', 'admin', 'CV', 'admin'),
(25, 'Beerus', 'boss', 'boss', 'CV', 'boss'),
(26, 'Haji Isam', 'haji', 'haji', 'CV', 'user');
