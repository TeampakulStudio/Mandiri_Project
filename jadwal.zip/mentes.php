<?php 
require_once ('koneksi.php');

?>

<?php 

 if(isset($_POST['submit'])){
 	$arr = array("a" => "one", "b" => "two", "c" => "blue");

function addQuotes($str){
    return "'$str'";
}



 
 	  				 $a           = $_POST['a'];
 	  				  $b           = $_POST['b'];
 	  				   $c           = $_POST['c'];
 	  				    $d           = $_POST['d'];
 	  				    $jum_array    = count($a);
              echo "asem";
              echo $jum_array;
               for($i=0;$i<$jum_array;$i++){
         		 $agunan = array(
                        'a' => $a[$i],
                        'b' => $b[$i],
                        'c' => $c[$i],
                        'd' => $d[$i]

                        );

      foreach ($arr as $key => &$value) {
    $value = addQuotes($value);
}


$columns = implode(",", array_keys($agunan));


$values = implode(",", array_values($agunan));


$query = "INSERT INTO mentes (".$columns.") VALUES (".$values.")";

echo $query;
  mysql_select_db($db, $koneksi);
  $Result1 = mysql_query($query, $koneksi) or die(mysql_error());

                        	}

$insertSQL = sprintf("INSERT INTO metes ( e ) VALUES ( %s)",
                    
                   
                       GetSQLValueString($_POST['e'], "text")) ;
                      

  mysql_select_db($db, $koneksi);
  $Result12 = mysql_query($insertSQL, $koneksi) or die(mysql_error());

 } ?>
<html>


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js">
		
	</script>
	<script>
		$(document).ready(function() {
    $("body").on("click",".add-more",function(){ 
        var html = $(".after-add-more").first().clone();
      
        //  $(html).find(".change").prepend("<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove'>- Remove</a>");
      
          $(html).find(".change").html("<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove'>- Remove</a>");
      
      
        $(".after-add-more").last().after(html);
      
     
       
    });

    $("body").on("click",".remove",function(){ 
        $(this).parents(".after-add-more").remove();
    });
});
	</script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
 <form id="a" method="POST">
 	<input maxlength="200" type="text" class="form-control" placeholder="e" name="e" />
 
   <div class="after-add-more"> 
    <input maxlength="200" type="text" class="form-control" placeholder="a" name="a[]" />
      <div class="after-add-more"> 
    <input maxlength="200" type="text" class="form-control" placeholder="b" name="b[]" />
      <div class="after-add-more"> 
    <input maxlength="200" type="text" class="form-control" placeholder="c" name="c[]" />
       <input maxlength="200" type="text" class="form-control" placeholder="d" name="d[]" />
     </div>	
    <div class="col-md-2">
        <div class="form-group change">
            <label for="">&nbsp;</label><br/>
            <a class="btn btn-success add-more">+ Add More</a>

        </div>
    </div>
    <button type="submit" name="submit" >Submit</button>
    




</html>