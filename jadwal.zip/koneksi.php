<?php
$host="localhost";
$user="root";
$pass="";
$db="jadwal";

$koneksi=mysql_connect($host,$user,$pass);
$con=mysql_connect($host,$user,$pass,$db);
$conn=mysqli_connect($host,$user,$pass,$db);
mysql_select_db($db,$koneksi);

if (!$koneksi){
	echo "Gagal konesi";
	}
	?>
