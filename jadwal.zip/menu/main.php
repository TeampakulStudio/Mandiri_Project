<div class="alert alert-info">
									<button class="close" data-dismiss="alert">
										<i class="ace-icon fa fa-times"></i>
									</button>

									<i class="ace-icon fa fa-hand-o-right"></i>
									Selamat Datang &nbsp; "<?php echo $_SESSION['nama']; ?>"
								</div>
<style>

	#logo {
    display: block;
    margin: auto;
    width: 100%;
    height: 500px;
}
</style>
<img id="logo" src="assets/images/bg.png"  />
