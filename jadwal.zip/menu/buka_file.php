<?php
if($_GET) {
	switch ($_GET['page']){				
		
		case 'beranda' :				
			if(!file_exists ("views/jadwal.php")) die ("Sorry Empty Page!"); 
			include "views/jadwal.php";						
		break;
		case 'main' :				
			if(!file_exists ("views/bos.php")) die ("Sorry Empty Page!"); 
			include "views/bos.php";						
		break;
		case 'workplane' :				
			if(!file_exists ("views/workplane.php")) die ("Sorry Empty Page!"); 
			include "views/workplane.php";						
		break;
			case 'checklist' :				
			if(!file_exists ("views/checklist.php")) die ("Sorry Empty Page!"); 
			include "views/checklist.php";						
		break;
		
		
		
		

		# MASTER DATA
		case 'user' :				
			if(!file_exists ("views/user_data.php")) die ("Sorry Empty Page!"); 
			include "views/user_data.php";	 break;	
		case 'user-edit' :				
			if(!file_exists ("views/user_edit.php")) die ("Sorry Empty Page!"); 
			include "views/user_edit.php"; break;		

			

	
		
		
		# SURAT PENGANTAR
		case 'surat_pengantar' :				
			if(!file_exists ("views/surat_pengantar_data.php")) die ("Sorry Empty Page!"); 
			include "views/surat_pengantar_data.php"; break;		
		case 'surat_pengantar_edit' :				
			if(!file_exists ("views/surat_pengantar_edit.php")) die ("Sorry Empty Page!"); 
			include "views/surat_pengantar_edit.php"; break;	

		case 'surat_pengantar_print' :				
			if(!file_exists ("print/surat_pengantar_print.php")) die ("Sorry Empty Page!"); 
			include "print/surat_pengantar_print.php"; break;	

		# SURAT PENGANTAR
		case 'surat_roya' :				
			if(!file_exists ("views/surat_roya_data.php")) die ("Sorry Empty Page!"); 
			include "views/surat_roya_data.php"; break;		
		case 'surat_roya_edit' :				
			if(!file_exists ("views/surat_roya_edit.php")) die ("Sorry Empty Page!"); 
			include "views/surat_roya_edit.php"; break;	

		case 'surat_roya_print' :				
			if(!file_exists ("print/surat_roya_print.php")) die ("Sorry Empty Page!"); 
			include "print/surat_roya_print.php"; break;



		# SURAT BAST
		case 'surat_bast' :				
			if(!file_exists ("views/surat_bast_data.php")) die ("Sorry Empty Page!"); 
			include "views/surat_bast_data.php"; break;		
		case 'beranda' :				
			if(!file_exists ("views/jadwal.php")) die ("Sorry Empty Page!"); 
			include "views/jadwal.php"; break;		
		case 'surat_bast_edit' :				
			if(!file_exists ("views/surat_bast_edit.php")) die ("Sorry Empty Page!"); 
			include "views/surat_bast_edit.php"; break;	

		case 'surat_bast_print' :				
			if(!file_exists ("print/surat_bast_print.php")) die ("Sorry Empty Page!"); 
			include "print/surat_bast_print.php"; break;	
		
	
	
		

	
		default:
			if(!file_exists ("main.php")) die ("Empty Main Page!"); 
			include "main.php";						
		break;
	}
}
else {
	if(!file_exists ("views/jadwal.php")) die ("Empty Main Page!"); 
		include "menu/main.php";	
}
?>