<?php 
require_once ('koneksi.php');
require_once ('menu/kunci.php');

if($_SESSION['role']=='admin'){


} else {
  echo '<script type="text/javascript">
           window.location = "?page=beranda"
      </script>';
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO tb_user ( nama, username, password, unit, role) VALUES ( %s, %s, %s, %s, %s)",
                    
					    GetSQLValueString($_POST['nama'], "text"),
                       GetSQLValueString($_POST['username'], "text"),
                          GetSQLValueString($_POST['password'], "text"),
                             GetSQLValueString($_POST['unit'], "text"),
                       GetSQLValueString(($_POST['role']), "text"));


  mysql_select_db($db, $koneksi);
  $Result1 = mysql_query($insertSQL, $koneksi) or die(mysql_error());

  $insertGoTo = "?page=user";
 if ($insertSQL) {
  echo "<script type='text/javascript'>alert('Akun Berhasil ditambahkan !');
  location.href=\"?page=user\";</script>";
}
 
}

mysql_select_db($db, $koneksi);
$query_barang = "SELECT * FROM tb_user";
$barang = mysql_query($query_barang, $koneksi) or die(mysql_error());
$row_barang = mysql_fetch_assoc($barang);
$totalRows_barang = mysql_num_rows($barang);
?>
	<?php require_once('koneksi.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}


mysql_select_db($db, $koneksi);
$query_prs = "SELECT * FROM tb_user";
$prs = mysql_query($query_prs, $koneksi) or die(mysql_error());
$row_prs = mysql_fetch_assoc($prs);
$totalRows_prs = mysql_num_rows($prs);
?>
<body>
   
						<script type="text/javascript">
							try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
						</script>

						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="?page=beranda">Home</a>
							</li>

							<li>
								<a href="#">User Data</a>
							</li>
							
						</ul>
				
    <br><br>
                 <button type="button" class="btn btn-primary " data-toggle="modal" data-target="#modal-table"><i class="fa fa-plus"> Tambah Akun</i></button><br><br>
                
                  
                     <table id="dynamic-table" class="table table-hover">
												<thead>
                           <tr>
                             <td><b>No</b></td>
							 <td><b>Nama</b></td>
                             <td><b>Username</b></td>
                          
                             <td><b>Unit</b></td>
                             <td><b>Role</b></td>
                        
                            
							 <td align="center"><b>Opsi</b></td>
                           </tr>
                       </thead>    
                       <?php $no=1; do { ?>
                         <tr>
                           <td><?php echo $no; ?></td>
						   <td><?php echo $row_prs['nama']; ?></td>
                           <td><?php echo $row_prs['username']; ?></td>
                 
                              <td><?php echo $row_prs['unit']; ?></td>
                                 <td><?php echo $row_prs['role']; ?></td>
          

						   
						   <td align="center">
                           <a href="?page=user-edit&id_user=<?php echo $row_prs['id_user']; ?>" target="_self" alt="Edit Data">
                           <button type="submit" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i></button></a>
                           <a href="views/user_delete.php?id_user=<?php echo $row_prs['id_user']; ?>" onclick="return confirm('Apakah Anda Yakin Menghapus Akun ini ?')"><button class="btn btn-danger btn-xs"><i class="fa fa-trash-o"> </i></button></a>                      </td>
                         </tr>
                         <?php $no++; } while ($row_prs = mysql_fetch_assoc($prs)); ?>
                     </table>
                  </div><!-- /.col -->
						</div><!-- /.row -->
</div><!-- /.page-content -->
				</div>
			</div

                                

<script src="assets/js/jquery.dataTables.min.js"></script>
<script src="assets/js/jquery.dataTables.bootstrap.min.js"></script>
<script src="assets/js/dataTables.tableTools.min.js"></script>
<script src="assets/js/dataTables.colVis.min.js"></script>

		<!-- ace scripts -->
<script src="assets/js/ace-elements.min.js"></script>
<script src="assets/js/ace.min.js"></script>

		<!-- inline scripts related to this page -->
        
        <p>&nbsp;</p>
<script type="text/javascript">
			jQuery(function($) {
				//initiate dataTables plugin
				var oTable1 = 
				$('#dynamic-table')
				//.wrap("<div class='dataTables_borderWrap' />")   //if you are applying horizontal scrolling (sScrollX)
				.dataTable( {
					bAutoWidth: false,
					"aoColumns": [
					  { "bSortable": false },
					  null, null, null,     null,
					  { "bSortable": false }
					],
					"aaSorting": [],
			
			    } );
				//oTable1.fnAdjustColumnSizing();
			
			
			})
		</script> 
									
									<div id="modal-table" class="modal fade" tabindex="-1">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header no-padding">
												<div class="table-header">
													<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
														<span class="white">&times;</span>
													</button>
													Daftar User
												</div>
											</div>

											<div class="modal-body no-padding">
									<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">

  <table align="center">
  <tr valign="baseline">
     <br> <td width="493" height="25"><input type="text" name="nama" value="" size="32" class="form-control" placeholder="Nama" required/><br></td>
    </tr>
    <tr valign="baseline">
     <br> <td width="493" height="25"><input type="text" name="username" value="" size="32" class="form-control" placeholder="Username" required/><br></td>
    </tr>
     <tr valign="baseline">
      <td><input type="password" name="password" value="" size="32"  class="form-control" placeholder="Password" required/><br></td>
    </tr>
    <tr valign="baseline">
      <td>

<select name="unit" class="form-control" required>
  <option value="" disabled selected>Pilih Unit</option>
  <option value="CV">CV</option>
  <option value="CCLA">CCLA</option>
  <option value="LMP/CISSS">LMP/CISSS</option>

</select>
        <br></td>
    </tr>

      <tr valign="baseline">
      <td>

<select name="role" class="form-control" required>
  <option value="" disabled selected>Pilih Role</option>
  <option value="admin">Admin</option>
  <option value="boss">Boss</option>
  <option value="user">User</option>

</select>
        <br></td>
    </tr>
     
     
  
  
      <tr valign="baseline">

     <td align="right"><button type="submit" class="btn btn-primary btn-xs"><i class="fa fa-plus"> Tambah Akun</i></button><br></td></tr>
       <td>&nbsp</td>
   
  <input type="hidden" name="MM_insert" value="form1" />

	</form></table>
											</div>

											<div class="modal-footer no-margin-top">
												<button class="btn btn-sm btn-danger pull-left" data-dismiss="modal">
													<i class="ace-icon fa fa-times"></i>
													Close
												</button>

												
											</div>
										</div><!-- /.modal-content -->
									</div><!-- /.modal-dialog -->
								</div>
        			
        					
		
   			    </form>
              </div>
      </div>
</div>
</div>
<p>&nbsp;</p>
</body>
<?php
mysql_free_result($barang);
?>
