<?php
// Range.php


if(isset($_POST["From"]))
{
	
	$result = '';

	$query = "SELECT * FROM jadwal WHERE tanggal = '".$_POST["From"]."'";
	$sql = mysqli_query($conn, $query);
	$result .='
	';
	if(mysqli_num_rows($sql) > 0)
	{
		while($row = mysqli_fetch_array($sql))
		{
			$result .='
			
<tr>
<td>'.$row["list_todo"].' </td>
<td>'.$row["durasi"].' Jam</td>
 </tr>';
		}
	}
	else
	{
		$result .='
		';
	}
	$result .='';
	echo $result;
}
?>