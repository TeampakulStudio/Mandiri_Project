
  <?php 
  require_once ('koneksi.php');

  if(isset($_POST['submit'])){
  $from                 = $_POST['From'];
   $todo                = $_POST['todo'];
    $durasi                 = $_POST['durasi'];

$query1 = "INSERT INTO jadwal (`list_todo`,`durasi`,`tanggal`) VALUES ('$_POST[todo]','$_POST[durasi]','$_POST[From]')";
mysql_select_db($db, $koneksi);
$Result = mysql_query($query1, $koneksi) or die(mysql_error());

 }
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>


    
  </script>
  <script>
    $(document).ready(function() {
    $("body").on("click",".add-more",function(){ 
        var html = $(".after-add-more").first().clone();
      
        //  $(html).find(".change").prepend("<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove'>- Remove</a>");
      
          $(html).find(".change").html("<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove'>- Hapus Dokumen</a>");
      
      
        $(".after-add-more").last().after(html);
      
     
       

    });
       
       


    $("body").on("click",".remove",function(){ 
        $(this).parents(".after-add-more").remove();
    });
});


  </script>

  <script>
    $(document).ready(function() {
    $("body").on("click",".add-more2",function(){ 
        var html = $(".after-add-more2").first().clone();
      
        //  $(html).find(".change").prepend("<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove'>- Remove</a>");
      
          $(html).find(".change2").html("<label for=''>&nbsp;</label><br/><a class='btn btn-danger remove'>- Hapus Dokumen</a>");
      
      
        $(".after-add-more2").last().after(html);
      
     
       

    });
       
       


    $("body").on("click",".remove",function(){ 
        $(this).parents(".after-add-more2").remove();
    });
});


  </script>
 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

      



<center><h1><b><u>CHECKLIST</u></b></h1></center>
 


<?php

$query = "SELECT * FROM jadwal ORDER BY id desc";
$sql = mysqli_query($conn, $query);
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title</title>
<link href="./assets/bootstrap-3.3.7/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css"/>
</head>

<body>

<br/>
<div class="container">
  <form id="a" method="POST">
<br/>
<br/>
<div class="col-md-2">
<input type="text" name="From" id="From" class="form-control" value="<?php echo date('Y-m-d'); ?>"/>
</div>

<div class="col-md-8">
<input type="button" name="range" id="range" value="Tanggal" class="btn btn-success"/>
</div>
<div class="clearfix"></div>
<br/>
<div class="col-md-12">
<div id="purchase_order">
<table class="table table-bordered">
<tr>
<th width="75%">To Do List</th>
<th width="25%">Durasi</th>
</tr>

<?php
$now = date("Y-m-d");
  $result = '';
  $query = "SELECT * FROM jadwal WHERE tanggal = '".$now."'";
  $sql = mysqli_query($conn, $query);
  $result .='
';
  if(mysqli_num_rows($sql) > 0)
  {
    $i=0;
    while($row = mysqli_fetch_array($sql))
    {
      
      $result .='
<tr>
<td>'.$row["list_todo"].' </td>
<td>'.$row["durasi"].' Jam</td>
 </tr>

      ';
      $i=$i+1;
 
    }
  }
  else
  {
    $result .='
    <tr>
    <td colspan="5">List Empty</td>
    </tr>';
  }
  $result .='</table>';
  echo $result;
?>
</div>

 

 <button type="submit" class="btn btn-primary" name="submit" >Update</button>



  

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.js"></script>
<!-- Script -->



<?php 
include 'komentar.php' ?>
<script>



$(document).ready(function(){
  $.datepicker.setDefaults({
    dateFormat: 'yy-mm-dd'
  });
  $(function(){
    $("#From").datepicker();
    $("#to").datepicker();
  });
  $('#range').click(function(){
    var From = $('#From').val();
    var to = $('#to').val();
    if(From != '')
    {
      $.ajax({
        url:"range.php",
        method:"POST",
        data:{From:From, to:to},
        success:function(data)
        {
          $('#purchase_order').html(data);
        }
      });
    }
    else
    {
      alert("Please Select the Date");
    }
  });
});
</script>

</body>
</html>
      
   
        </div>


</div>


    </div>
</div>


</>
</body>
</html>