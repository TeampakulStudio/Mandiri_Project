<?php 
require_once ('koneksi.php');
require_once ('menu/kunci.php');
if($_SESSION['role']=='admin'){


} else {
  echo '<script type="text/javascript">
           window.location = "?page=beranda"
      </script>';
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE tb_user SET nama=%s, username=%s, password=%s, unit=%s , role=%s WHERE id_user=%s",
                       GetSQLValueString($_POST['nama'], "text"),
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['password'], "text"),
                       GetSQLValueString($_POST['unit'], "text"),
                       GetSQLValueString($_POST['role'], "text"),
                       GetSQLValueString($_POST['id_user'], "int"));

  mysql_select_db($db, $koneksi);
  $Result1 = mysql_query($updateSQL, $koneksi) or die(mysql_error());

  $updateGoTo = "?page=user";
   if ($updateSQL) {
  echo "<script type='text/javascript'>alert('Data berhasil diedit');
  location.href=\"?page=user\";</script>";
}
}

$colname_z = "-1";
if (isset($_GET['id_user'])) {
  $colname_z = $_GET['id_user'];
}
mysql_select_db($db, $koneksi);
$query_z = sprintf("SELECT * FROM tb_user WHERE id_user = %s ORDER BY id_user ASC", GetSQLValueString($colname_z, "int"));
$z = mysql_query($query_z, $koneksi) or die(mysql_error());
$row_z = mysql_fetch_assoc($z);
$totalRows_z = mysql_num_rows($z);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<div class="breadcrumbs" id="breadcrumbs">
  <script type="text/javascript">
							try{ace.settings.check('breadcrumbs' , 'fixed')}catch(e){}
						</script>

						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i>
								<a href="?page=user">User Data</a>
							</li>

							<li>
								<a href="#">Edit User</a>
							</li>
							
						</ul>
</div>
    <br>

<p>&nbsp;</p>
<form action="<?php echo $editFormAction; ?>" method="post" name="form1" id="form1">
  <table align="left">
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"></td>
      <td>Nama<input type="text" class="form-control" name="nama" value="<?php echo htmlentities($row_z['nama'], ENT_COMPAT, 'utf-8'); ?>" size="32" /><br /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"></td>
      <td>Username<input type="text" name="username" class="form-control" value="<?php echo htmlentities($row_z['username'], ENT_COMPAT, 'utf-8'); ?>" size="32" /><br /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"></td>
      <td>Password<input type="text" class="form-control" name="password" value="<?php echo htmlentities($row_z['password'], ENT_COMPAT, 'utf-8'); ?>" size="32" /><br /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right"></td>
      <td>Unit<select name="unit" value="asd" class="form-control" required>
  <option value="<?php echo htmlentities($row_z['unit'], ENT_COMPAT, 'utf-8'); ?>" selected><?php echo htmlentities($row_z['unit'], ENT_COMPAT, 'utf-8'); ?></option>
  <option value="CV">CV</option>
  <option value="CCLA">CCLA</option>
  <option value="LMP/CISSS">LMP/CISSS</option>

</select><br /></td>
    </tr>
      <tr valign="baseline">
      <td nowrap="nowrap" align="right"></td>
      <td>Role
        <select name="role" class="form-control" required>
 <option value="<?php echo htmlentities($row_z['role'], ENT_COMPAT, 'utf-8'); ?>" selected><?php echo htmlentities($row_z['role'], ENT_COMPAT, 'utf-8'); ?></option>
  <option value="admin">Admin</option>
  <option value="boss">Boss</option>
  <option value="user">User</option>

</select><br /></td>
    </tr>
    <tr valign="baseline">
      <td nowrap="nowrap" align="right">&nbsp;</td>
      <td><button type="submit" class="btn btn-info btn-xs">Simpan</button>&nbsp;&nbsp; <a   class="btn btn-info btn-xs"  href="?page=user">Kembali</a></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1" />
  <input type="hidden" name="id_user" value="<?php echo $row_z['id_user']; ?>" />
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($z);
?>
