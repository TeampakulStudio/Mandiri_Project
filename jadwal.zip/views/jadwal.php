
  <?php 
  require_once ('koneksi.php');

  if(isset($_POST['submit'])){
  $from                 = $_POST['From'];
   $todo                = $_POST['todo'];
    $durasi                 = $_POST['durasi'];

$query1 = "INSERT INTO jadwal (`list_todo`,`durasi`,`tanggal`) VALUES ('$_POST[todo]','$_POST[durasi]','$_POST[From]')";
mysql_select_db($db, $koneksi);
$Result = mysql_query($query1, $koneksi) or die(mysql_error());

 }
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>




<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css"/>
   <link rel="stylesheet" href="assets/Ionicons/css/ionicons.min.css">
        <link rel="stylesheet" href="assets/dist/css/AdminLTE.min.css">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
    .ui-datepicker {
width: 7cm; 
}
</style>
</head>

<body>

   <?php 


   $now = date("Y-m-d");
$user = $_SESSION['nama'];

     $result = mysqli_query($conn, "SELECT COUNT(list_todo) AS `count` FROM `jadwal`  WHERE tanggal = '".$now."' AND user =  '".$user."' ");
$row = mysqli_fetch_array($result);
$count = $row['count'];




    ?>
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-blue"  onclick="window.location='home.php?page=workplane'";>
            <div class="inner">
              <h3><?php echo $count;
 ?></h3>

              <p>Workplane Today&nbsp&nbsp&nbsp&nbsp</p>

            </div>
            <div class="icon">
              <i class="ion ion-document-text"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
         <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow"  onclick="window.location='home.php?page=checklist'">
            <div class="inner">
              <h3>0</h3>

              <p>Workplane Checklist</p>
            </div>
            <div class="icon">
              <i class="ion ion-android-done-all"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
   
      </div>



<center><h1><b><u>TODAY LIST</u></b></h1></center>
 


<?php

$query = "SELECT * FROM jadwal ORDER BY id desc";
$sql = mysqli_query($conn, $query);
?>




<body>

<br/>
<div class="container">
  <form id="a" method="POST">
<br/>
<br/>
<div class="col-md-2">
<input type="text" name="From" id="From" class="form-control" value="<?php echo date('Y-m-d'); ?>"/>
</div>

<div class="col-md-8">
<input type="button" name="range" id="range" value="Set Date" class="btn btn-success"/>
</div>
<div class="clearfix"></div>
<br/>
<div class="col-md-12">
<div id="purchase_order">
<table class="table table-bordered">
<tr>
<th width="75%">To Do List</th>
<th width="25%">Duration</th>
</tr>

<?php
$now = date("Y-m-d");
$user = $_SESSION['nama'];
  $result = '';
  $query = "SELECT * FROM jadwal WHERE tanggal = '".$now."' AND user =  '".$user."' ";
  $sql = mysqli_query($conn, $query);
  $result .='
';
  if(mysqli_num_rows($sql) > 0)
  {
    $i=0;
    while($row = mysqli_fetch_array($sql))
    {
      
      $result .='
<tr>
<td>'.$row["list_todo"].' </td>
<td>'.$row["durasi"].' Jam</td>
 </tr>

      ';
      $i=$i+1;

    }
  }
  else
  {
    $result .='
    <tr>
    <td colspan="5">List Empty</td>

    </tr>';
  }
  $result .='';
  echo $result;
?>
</div>

  

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.js"></script>
<!-- Script -->



<?php 
include 'komentar.php' ?>
<script>



$(document).ready(function(){
  $.datepicker.setDefaults({
    dateFormat: 'yy-mm-dd'
  });
  $(function(){
    $("#From").datepicker();
    $("#to").datepicker();
  });
  $('#range').click(function(){
    var From = $('#From').val();
    var to = $('#to').val();
    if(From != '')
    {
      $.ajax({
        url:"range.php",
        method:"POST",
        data:{From:From, to:to},
        success:function(data)
        {
          $('#purchase_order').html(data);
        }
      });
    }
    else
    {
      alert("Please Select the Date");
    }
  });
});
</script>


</html>
      
   
        </div>


</div>


    </div>
</div>


</>
</body>
</html>