
  <?php 
  require_once ('koneksi.php');

  if(isset($_POST['submit'])){
  $from                 = $_POST['From'];
   $todo                = $_POST['todo'];
    $durasi                 = $_POST['durasi'];

$query1 = "INSERT INTO jadwal (`list_todo`,`durasi`,`tanggal`,`user`,`unit`) VALUES ('$_POST[todo]','$_POST[durasi]','$_POST[From]','$_SESSION[nama]','$_SESSION[unit]')";
mysql_select_db($db, $koneksi);
$Result = mysql_query($query1, $koneksi) or die(mysql_error());

 }
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>

<center><h1><b><u>WORKPLANE</u></b></h1></center>
 


<?php
$query = "SELECT * FROM jadwal ORDER BY id desc";
$sql = mysqli_query($conn, $query);
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css"/>
<link rel="stylesheet" href="assets/Ionicons/css/ionicons.min.css">
        <link rel="stylesheet" href="assets/dist/css/AdminLTE.min.css">
        <style type="text/css">
    .ui-datepicker {
width: 7cm; 
}
</style>
</head>

<body>

<br/>
<div class="container">
  <form id="a" method="POST">
<br/>
<br/>
<div class="col-md-2">
<input type="text" name="From" id="From" class="form-control" value="<?php echo date('Y-m-d'); ?>"/>
</div>

<div class="col-md-8">
<input type="button" name="range" id="range" value="Set Date" class="btn btn-success"/>
</div>
<div class="clearfix"></div>
<br/>
<div class="col-md-12">
<div id="purchase_order">
<table class="table table-bordered">
<tr>
<th width="75%">To Do List</th>
<th width="25%">Duration</th>
</tr>

<?php
$now = date("Y-m-d");
$user = $_SESSION['nama'];
$unit = $_SESSION['unit'];
  $result = '';
  $query = "SELECT * FROM jadwal WHERE tanggal = '".$now."' AND user =  '".$user."' ";
  $sql = mysqli_query($conn, $query);
  $result .='
';
  if(mysqli_num_rows($sql) > 0)
  {
    $i=0;
    while($row = mysqli_fetch_array($sql))
    {
      
      $result .='
<tr>
<td>'.$row["list_todo"].' </td>
<td>'.$row["durasi"].' Jam</td>
 </tr>

      ';
      $i=$i+1;
 
    }
  }
  else
  {
    $result .='
    <tr>
    <td colspan="5">List Empty</td>
    </tr>';
  }
  $result .='</table>';
  echo $result;
?>
</div>

    <div class="col-md-13">
     <div class="panel panel-default">
  <div class="panel-body"> 

<div class="form-group col-md-4">
      <label>To Do</label>
      <input type="text" class="form-control" name="todo" placeholder="To Do">
    </div><div class="form-group col-md-4">
      <label>Duration</label>
      <input type="text" class="form-control" name="durasi" placeholder="Duration">
    </div>
      </div>
</div> <button type="submit" class="btn btn-primary" name="submit" >Submit</button>

</div>

  

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.js"></script>
<!-- Script -->



<?php 
include 'komentar.php' ?>
<script>



$(document).ready(function(){
  $.datepicker.setDefaults({
    dateFormat: 'yy-mm-dd'
  });
  $(function(){
    $("#From").datepicker();
    $("#to").datepicker();
  });
  $('#range').click(function(){
    var From = $('#From').val();
    var to = $('#to').val();
    if(From != '')
    {
      $.ajax({
        url:"range.php",
        method:"POST",
        data:{From:From, to:to},
        success:function(data)
        {
          $('#purchase_order').html(data);
        }
      });
    }
    else
    {
      alert("Please Select the Date");
    }
  });
});
</script>

</body>
</html>
      
   
        </div>


</div>


    </div>
</div>


</>
</body>
</html>













