<script>
    $("input[type='radio'][name='group0']").change(function(){
if($(this).val()=="No")
{
    $("#otherAnswer0").show();
}
else
{
    $("#otherAnswer0").hide(); 
} 
});


$("input[type='radio'][name='group1']").change(function(){
if($(this).val()=="No")
{
    $("#otherAnswer1").show();
}
else
{
    $("#otherAnswer1").hide(); 
} 
});

$("input[type='radio'][name='group2']").change(function(){
if($(this).val()=="No")
{
    $("#otherAnswer2").show();
}
else
{
    $("#otherAnswer2").hide(); 
} 
});


$("input[type='radio'][name='group3']").change(function(){
if($(this).val()=="No")
{
    $("#otherAnswer3").show();
}
else
{
    $("#otherAnswer3").hide(); 
} 
});


$("input[type='radio'][name='group4']").change(function(){
if($(this).val()=="No")
{
    $("#otherAnswer4").show();
}
else
{
    $("#otherAnswer4").hide(); 
} 
});


$("input[type='radio'][name='group5']").change(function(){
if($(this).val()=="No")
{
    $("#otherAnswer5").show();
}
else
{
    $("#otherAnswer5").hide(); 
} 
});


$("input[type='radio'][name='group6']").change(function(){
if($(this).val()=="No")
{
    $("#otherAnswer6").show();
}
else
{
    $("#otherAnswer6").hide(); 
} 
});


$("input[type='radio'][name='group7']").change(function(){
if($(this).val()=="No")
{
    $("#otherAnswer7").show();
}
else
{
    $("#otherAnswer7").hide(); 
} 
});


$("input[type='radio'][name='group8']").change(function(){
if($(this).val()=="No")
{
    $("#otherAnswer8").show();
}
else
{
    $("#otherAnswer8").hide(); 
} 
});


$("input[type='radio'][name='group9']").change(function(){
if($(this).val()=="No")
{
    $("#otherAnswer9").show();
}
else
{
    $("#otherAnswer9").hide(); 
} 
});


$("input[type='radio'][name='group10']").change(function(){
if($(this).val()=="No")
{
    $("#otherAnswer10").show();
}
else
{
    $("#otherAnswer10").hide(); 
} 
});


$("input[type='radio'][name='group11']").change(function(){
if($(this).val()=="No")
{
    $("#otherAnswer11").show();
}
else
{
    $("#otherAnswer11").hide(); 
} 
});



</script>